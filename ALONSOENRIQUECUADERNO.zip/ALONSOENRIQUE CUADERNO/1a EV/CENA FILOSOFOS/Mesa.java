

public class Mesa {
     
    private boolean[] tenedores;
     
    public Mesa(int numTenedores){
        this.tenedores = new boolean[numTenedores];
    }
     
    public int tenedorIzquierda(int indiceComensal){
        return indiceComensal;
    }
     
    public int tenedorDerecha(int indiceComensal){
        if(indiceComensal == 0){
            return this.tenedores.length - 1;
        }else{
            return indiceComensal - 1;
        }
    }
     
    public synchronized void cogerTenedores(int comensal){
        boolean izquierda = tenedores[tenedorIzquierda(comensal)];
        boolean derecha = tenedores[tenedorDerecha(comensal)];
         
        while(izquierda || derecha){
            try {   
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
           
        }
         
        tenedores[tenedorIzquierda(comensal)] = true;
        tenedores[tenedorDerecha(comensal)] = true;
    }
     
    public synchronized void dejarTenedores(int comensal){
        tenedores[tenedorIzquierda(comensal)] = false;
        tenedores[tenedorDerecha(comensal)] = false;
        notifyAll();
    }
     
}