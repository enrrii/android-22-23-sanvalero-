/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Enrique Alonso
 */
public class Cajera extends Thread{
    
    private String nombre;
    private Cliente cliente;

    public Cajera(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    public void procesarCompra(Cliente cliente){
        this.setCliente(cliente);
        this.start();
        
    }
    
    @Override
    public void run(){
        int tiempo = 0;
        System.out.println("La cajera "+this.nombre+" COMIENZA A PROCESAR LA COMPRA DEL CLIENTE "+cliente.getNombre()+" EN EL TIEMPO: 0");
        
        for(int i = 0; i<cliente.getCarroCompra().length;i++){
            
            try {
            this.sleep(cliente.getCarroCompra()[i]*1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(cliente.getNombre()).log(Level.SEVERE, null, ex);
            }
            tiempo = tiempo + cliente.getCarroCompra()[i];
            System.out.println("Procesando el producto "+i+" del cliente "+cliente.getNombre()+"->Tiempo: "+tiempo+"seg");
            
        }
        System.out.println("La cajera "+this.nombre+" HA TERMINADO DE PROCESAR "+cliente.getNombre()+" EN EL TIEMPO: "+tiempo+"seg");
        
    }
    
}
