
package ejercicio2;
/**
 *
 * @author Enrique Alonso
 */
public class Ejercicio2 {

    public static void main(String[] args) {
        
        Cliente cliente1 = new Cliente("Cliente 1", new int[] { 2, 2, 1, 5, 2, 3 });
        Cajera cajera1 = new Cajera("Cajera 1");
         
        cajera1.procesarCompra(cliente1);
        
        
        
    }
    
}
