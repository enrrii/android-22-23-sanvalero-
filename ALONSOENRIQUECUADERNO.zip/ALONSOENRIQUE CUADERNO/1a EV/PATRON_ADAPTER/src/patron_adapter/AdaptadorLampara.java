/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patron_adapter;

/**
 *
 * @author A10-PC123
 */
public class AdaptadorLampara implements Conectable{
    private LamparaInglesa lInglesa

    @Override
    public void isEncendida() {
        return this.lInglesa.isOn();
        
    }

    @Override
    public void encender() {
        this.isEncendida();
    }

    @Override
    public void apagar() {
        this.isEncendida();
       
    }
    
}
