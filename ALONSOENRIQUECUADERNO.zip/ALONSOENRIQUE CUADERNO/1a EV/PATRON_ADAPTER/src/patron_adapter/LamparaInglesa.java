/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patron_adapter;

/**
 *
 * @author A10-PC123
 */
public class LamparaInglesa {
    private boolean isOn;
    
    public boolean isOn(){
        return this.isOn;
    }
    public void on(){
        this.isOn = true;
        
    }
    public void off(){
        this.isOn = false; 
    }
}
