/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patron_adapter;

/**
 *
 * @author A10-PC123
 */
public class PATRON_ADAPTER {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Lampara lampara = new Lampara();
        Conectable ordenador = new Ordenador();
        
        
        lampara.encender();
        System.out.println("Está encendida: " + lampara.isEncendida());
        ordenador.encender();
        System.out.println("Está encendida: " + ordenador.isEncendida());
        
    }
    private static void encenderAparato(Conectable l1){
        l1.encender();
        System.out.println("l1.isEncendida");
    }
    
}
