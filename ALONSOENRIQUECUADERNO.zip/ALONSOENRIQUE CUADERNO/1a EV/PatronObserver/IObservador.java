package PatronObserver;

public interface IObservador
{
    public void observadoActualizado();
}
