package PatronObserver;

public class UnObservado extends Observado
{
    public UnObservado() {
    }
}
