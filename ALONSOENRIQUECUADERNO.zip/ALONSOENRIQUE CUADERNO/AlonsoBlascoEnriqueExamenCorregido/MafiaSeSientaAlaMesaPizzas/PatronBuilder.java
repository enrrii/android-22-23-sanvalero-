public class PatronBuilder {

     
    public static void main(String[] args) {
        Cocina cocina = Cocina.getInstance();
        
   
        PizzaBuilder picantePizza = new PicantePizzaBuilder();
        PizzaBuilder barbacoaPizza = new BarbacoaPizzaBuilder();
        PizzaBuilder carbonaraPizza = new CarbonarayPolloPizzaBuilder();
        
        
        cocina.setPizzaBuilder(picantePizza);
        cocina.construirPizza();

        cocina.setPizzaBuilder(barbacoaPizza);
        cocina.construirPizza();

        cocina.setPizzaBuilder(carbonaraPizza);
        cocina.construirPizza();
        
        
        
    }
    
}
