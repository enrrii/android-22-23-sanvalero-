package MafiaSeSienteAlaMesaCacos;

public class Comisario extends Personaje{
    
    private Jefe jefe;
    private int sobornoMes;

    public Comisario(Jefe jefe, int sobornoMes) {
        this.jefe = jefe;
        this.sobornoMes = sobornoMes;
    }

    public Jefe getJefe() {
        return jefe;
    }

    public void setJefe(Jefe jefe) {
        this.jefe = jefe;
    }

    public int getSobornoMes() {
        return sobornoMes;
    }

    public void setSobornoMes(int sobornoMes) {
        this.sobornoMes = sobornoMes;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
}
