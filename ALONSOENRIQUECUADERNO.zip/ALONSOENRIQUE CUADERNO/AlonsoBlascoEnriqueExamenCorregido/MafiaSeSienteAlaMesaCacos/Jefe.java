package MafiaSeSienteAlaMesaCacos;

public class Jefe extends Personaje{
    
    private int[] cacos;
 
     public Jefe(int[] cacos) {
         this.cacos = cacos;
         this.nombre = super.nombre;
     }
 
     public int[] getCacos() {
         return cacos;
     }
 
     public void setCacos(int[] cacos) {
         this.cacos = cacos;
     }
 
     public String getNombre() {
         return nombre;
     }
 
     public void setNombre(String nombre) {
         this.nombre = nombre;
     }
     
     }
    
    
 