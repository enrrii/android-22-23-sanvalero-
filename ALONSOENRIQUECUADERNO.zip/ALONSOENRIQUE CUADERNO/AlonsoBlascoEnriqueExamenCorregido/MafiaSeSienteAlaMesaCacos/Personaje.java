package MafiaSeSienteAlaMesaCacos;

public abstract class Personaje {
    protected String nombre;

    public Personaje() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
    
}
