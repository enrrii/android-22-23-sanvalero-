package MafiaSeSienteAlaMesaCacos;

public class caco1 extends Personaje {
    
    private int salario_dia;

    public caco1(int salario_dia) {
        this.salario_dia = 30;
    }

    public int getSalario_dia() {
        return salario_dia;
    }

    public void setSalario_dia(int salario_dia) {
        this.salario_dia = salario_dia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}
