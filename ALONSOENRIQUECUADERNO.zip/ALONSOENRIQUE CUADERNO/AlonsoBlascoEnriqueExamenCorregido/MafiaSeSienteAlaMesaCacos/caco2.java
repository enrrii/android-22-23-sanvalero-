package MafiaSeSienteAlaMesaCacos;

public class caco2 extends Personaje {
    
    private int sueldo_dia;

    public caco2(int salario_dia) {
        this.sueldo_dia = 25;
    }

    public int getSalario_dia() {
        return sueldo_dia;
    }

    public void setSalario_dia(int salario_dia) {
        this.sueldo_dia = salario_dia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}
