package MafiaSeSienteAlaMesaCacos;

public class caco3 extends Personaje {
    
    private int sueldo_dia;

    public caco3(int salario_dia) {
        this.sueldo_dia = 20;
    }

    public int getSalario_dia() {
        return sueldo_dia;
    }

    public void setSalario_dia(int salario_dia) {
        this.sueldo_dia = salario_dia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}
